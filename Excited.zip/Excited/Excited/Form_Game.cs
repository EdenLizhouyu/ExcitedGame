﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Media;

namespace Excited
{
    public partial class Form_Game : Form
    {
        /*-----------------------------委托-------------------------------*/
        public delegate void SetSelectabilityEventHandler(int i, int j, int Flag);
        public delegate void MarkCubeEventHandler(Cube cube);    //标记方块
        public delegate void deMarkCubeEventHandler(Cube cube);  //取消标记方块
        public delegate void TimeBarMoveEventHandler();    //时间条移动
        public delegate void TimeBarInitialEventHandler(int time); //时间条初始化
        public delegate void TimeLabelUpdateEventHandler(int time);  //时间计数
        public delegate void ReDrawInterfaceEventHandler(Cube[,] map);  //重绘主界面
        public delegate void PutIntoSelectedListEventHandler(Cube cube);  //将已选择的方块加入已选链表
        public delegate void RemoveFromSelectedListEventHandler(Cube cube);  //将已选择的方块移出已选链表
        public delegate void SetTimeAdd1sLabelVisibililtyEventHandler(int LabelNum, Boolean visibility); //设置时间+1s标签的可见性
        public delegate void SetScoreAdd1sLabelVisibililtyEventHandler(int LabelNum, Boolean visibility); //设置时间+1s标签的可见性
        public delegate void SetScoreLabelTextEventHandler(int score); //设置分数标签的显示值
        public delegate void CloseFormEventHandler();   //关闭窗口
        public delegate void SetRestartGameButtonVisibleEventHandler(Boolean next_level);  //设置重新开始按钮可见

        /*----------------------------线程-------------------------------------*/
        private Thread thread_time_count;
        private Thread thread_scan_and_kill_cubes;
        private Thread thread_switch_listening;
        private Thread thread_Generate_new_cubes;
        //private Thread thread_vedio_listening;
        private Thread thread_restart_game;



        /*---------------------------游戏有关数据-----------------------------*/
        private Cube[,] map = new Cube[9, 12];  //游戏的地图（9*12矩阵）
        private List<Cube> marked_cubes = new List<Cube>();   //被标记的方块
        private int last_inherent_score;  //游戏剩余时间
        private int score; //游戏得分
        private int selected_cubes; //选中的方块数
        private static int thr_bonus_time = 3;    //奖励时间阈值
        private int TOTAL_CUBE_TYPE;   //方块类型总数
        private static int X_CUBES_NUM = 9;   //一行的方块数
        private static int Y_CUBES_NUM = 12;   //一列的方块数
        private int INITIAL_TIME;   //初始游戏时间
        private static String sound_path_head = System.AppDomain.CurrentDomain.BaseDirectory + @"components\sounds\";  //+ "Filename"   音效目录
        private List<Cube> Selected_cube_List = new List<Cube>(2);   //用于储存已选择的方块
        private Boolean Time_Need_Update; //用于表示时间需要清除的标志位
        private Boolean Time_Stop; //用于表示时间需要停止的标志位
        private int New_Time;  //更新的时间
        private int Vedio_Type; //视频类型
        private int Game_achievement = 0; // 游戏成绩

        private int Score_line_pass;  //过关分数线
        private int Score_line_average; //一般分数线
        private int Score_line_outstanding;//优秀分数线

        /*---------------------------构造函数和控件函数----------------------*/
        public Form_Game()
        {
            InitializeComponent();
            this.Game_achievement = 0;
            this.thread_time_count = new Thread(new ParameterizedThreadStart(time_count));
            this.thread_scan_and_kill_cubes = new Thread(new ThreadStart(Scan_and_Kill_cubes));
            this.thread_switch_listening = new Thread(new ThreadStart(Switch_listening));
            this.thread_Generate_new_cubes = new Thread(new ThreadStart(Generate_new_cubes));
            //this.thread_vedio_listening = new Thread(new ThreadStart(Vedio_Listening));
            this.thread_switch_listening.IsBackground = true;
            this.thread_time_count.IsBackground = true;
            this.thread_scan_and_kill_cubes.IsBackground = true;
            this.thread_Generate_new_cubes.IsBackground = true;
            //this.thread_vedio_listening.IsBackground = true;

            this.Time_Need_Update = false;
            this.Time_Stop = false;

        }

        public Form_Game(Object Game_achievement,Object inherent_score)
        {
            try
            {
                this.last_inherent_score = Convert.ToInt16(inherent_score);
                this.Game_achievement = Convert.ToInt16(Game_achievement);
                this.score = Convert.ToInt16(inherent_score);
                this.Game_achievement = (this.Game_achievement > 4 ? 4 : this.Game_achievement);
                InitializeComponent();
                String str_label_level = "";
                switch (Game_achievement)
                {
                    case 0: { INITIAL_TIME = 80; TOTAL_CUBE_TYPE = 5; str_label_level = "在国机二院当工程师"; break; }
                    case 1: { INITIAL_TIME = 60; TOTAL_CUBE_TYPE = 6; str_label_level = "上海市委书记"; break; }
                    case 2: { INITIAL_TIME = 50; TOTAL_CUBE_TYPE = 7; str_label_level = "我当总书记"; break; }
                    case 3: { INITIAL_TIME = 40; TOTAL_CUBE_TYPE = 8; str_label_level = "和华莱士谈笑风生"; break; }
                    case 4: { INITIAL_TIME = 30; TOTAL_CUBE_TYPE = 8; str_label_level = "怒斥香港记者"; break; }
                    case 5: { MessageBox.Show("Excited！"); }
                }
                this.label_level.Text = str_label_level;
                switch (Game_achievement)
                {
                    case 0: { Score_line_pass = 600; Score_line_average = 700;Score_line_outstanding = 800; break; }
                    case 1: { Score_line_pass = 900; Score_line_average = 1000;Score_line_outstanding = 1100; break; }
                    case 2: { Score_line_pass = 1000; Score_line_average = 1050; Score_line_outstanding = 1100; break; }
                    case 3: { Score_line_pass = 1100; Score_line_average = 1150; Score_line_outstanding = 1200; break; }
                    case 4: { Score_line_pass = 1150; Score_line_average = 1180; Score_line_outstanding = 1210; break; }
                }
            }
            catch(Exception e)
            {
                this.INITIAL_TIME = 30;
                this.TOTAL_CUBE_TYPE = 8;
                this.label_level.Text = "怒斥香港记者";
                MessageBox.Show(e.Message);
            }
            

            this.thread_time_count = new Thread(new ParameterizedThreadStart(time_count));
            this.thread_scan_and_kill_cubes = new Thread(new ThreadStart(Scan_and_Kill_cubes));
            this.thread_switch_listening = new Thread(new ThreadStart(Switch_listening));
            this.thread_Generate_new_cubes = new Thread(new ThreadStart(Generate_new_cubes));
            //this.thread_vedio_listening = new Thread(new ThreadStart(Vedio_Listening));
            this.thread_switch_listening.IsBackground = true;
            this.thread_time_count.IsBackground = true;
            this.thread_scan_and_kill_cubes.IsBackground = true;
            this.thread_Generate_new_cubes.IsBackground = true;
            //this.thread_vedio_listening.IsBackground = true;
            this.Time_Need_Update = false;
            this.Time_Stop = false;

        }
        /*--------------------------误触----------------------------*/
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form_Game_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        /*-------------------------有用的控件--------------------*/

        //开始按钮
        private void button_start_Click(object sender, EventArgs e)
        {
            this.button_start.Visible = false;
            this.thread_time_count.Start(INITIAL_TIME);
            Map_initial();
            Initial_Cubes(map);
            this.thread_scan_and_kill_cubes.Start();
            this.thread_switch_listening.Start();
            this.label_goal.Text = "目标分数" + this.Score_line_pass.ToString();
            //this.thread_vedio_listening.Start();
        }


        //重新开始按钮
        private void button_restart_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("这将再额外消耗你至少30秒的寿命，你确定吗？","得罪一下", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if(dialogResult == DialogResult.OK)
            {
                this.thread_restart_game = new Thread(new ParameterizedThreadStart(Restart_Game));
                this.thread_restart_game.Start(this.Game_achievement);
                this.Close();
            }

        }

        //设置重新开始按钮可见
        private void Set_RestartButton_Visible(Boolean next_level )
        {
            this.button_restart.Visible = true;
            if(next_level) { this.button_restart.Text = "继续历史的进程"; }
            else { this.button_restart.Text = "再续一局"; this.score = last_inherent_score; }
        }

        //设置时间+1s标签的显示与消失
        public void Set_time_add1s_label_visiblility(int LabelNum, Boolean visibility)
        {
            if(visibility == true)
            {
                switch (LabelNum)
                {
                    case 1: { this.label_time_add1s_1.Visible = true; break; }
                    case 2: { this.label_time_add1s_2.Visible = true; break; }
                    case 3: { this.label_time_add1s_3.Visible = true; break; }
                }
            }
            else
            {
                switch (LabelNum)
                {
                    case 1: { this.label_time_add1s_1.Visible = false; break; }
                    case 2: { this.label_time_add1s_2.Visible = false; break; }
                    case 3: { this.label_time_add1s_3.Visible = false; break; }
                }
            }

        }

        //设置分数+1s标签的显示与消失
        public void Set_score_add1s_label_visiblility(int LabelNum, Boolean visibility)
        {
            if (visibility == true)
            {
                switch (LabelNum)
                {
                    case 1: { this.label_add1s_1.Visible = true; break; }
                    case 2: { this.label_add1s_2.Visible = true; break; }
                    case 3: { this.label_add1s_3.Visible = true; break; }
                }
            }
            else
            {
                switch (LabelNum)
                {
                    case 1: { this.label_add1s_1.Visible = false; break; }
                    case 2: { this.label_add1s_2.Visible = false; break; }
                    case 3: { this.label_add1s_3.Visible = false; break; }
                }
            }

        }

        //设置分数标签显示值
        public void Set_Score_Label_Text(int new_score)
        {
            this.label_score.Text = new_score.ToString() + "s";
        }

        //关闭窗口
        public void Close_Form()
        {
            this.Close();
        }


        /*---------------------------游戏有关方法-----------------------------*/
        //重新开始游戏进程
        public void Restart_Game(Object Game_achievement)
        {
            Form_Game form_Game = new Form_Game(Game_achievement,this.score);
            form_Game.ShowDialog();
        }

            
        //初始化Map游戏地图
        public void Map_initial()
        {
            Random myRand = new Random(DateTime.Now.Second);
            int i, j;
            for (i = 0; i < X_CUBES_NUM; i++)
            {
                for (j = 0; j < Y_CUBES_NUM; j++)
                {
                    map[i, j] = new Cube(myRand.Next(1, TOTAL_CUBE_TYPE));
                }
            }


        }

        //初始化Cubes到penal
        public void Initial_Cubes(Cube[,] map)
        {
            int x, y;//方块的横纵坐标
            x = 25; //第一个方块左侧与panel相距为25
            y = 50; //第一个方块上侧与panel相距为50
            int i, j;
            for (j = 0; j < Y_CUBES_NUM; j++, x = 25, y += 39)
            {
                for (i = 0; i < X_CUBES_NUM; i++, x += 39)
                {
                    this.panel1.Controls.Add(map[i, j]);
                    map[i, j].Left = x;
                    map[i, j].Top = y;
                    Cube.Set_location(map[i, j], i, j);   //写入位置数据
                    map[i, j].SetSelectabilityEvent += new SetSelectabilityEventHandler(Set_Around_Selectability);   //在每个Cube上都注册设置选择使能的事件
                    map[i, j].MarkCubeEvent += new MarkCubeEventHandler(Mark_cube);  //在每个Cube上都注册标记方块的事件
                    map[i, j].deMarkCubeEvent += new deMarkCubeEventHandler(deMark_cube);  //在每个Cube上都注册取消标记方块的事件
                    map[i, j].PutIntoSelectedListEvent += new PutIntoSelectedListEventHandler(Put_cube_into_SelectList);   //在每个Cube上都注册加入已选列表的事件
                    map[i, j].RemoveFromSelectedListEvent += new RemoveFromSelectedListEventHandler(Remove_cube_from_SelectList);  //在每个Cube上都注册从已选列表移出的事件
                }
            }
        }

        //加载Cubes到penal
        public void Draw_Cubes(Cube[,] map)
        {
            int x, y;//方块的横纵坐标
            x = 25; //第一个方块左侧与panel相距为25
            y = 50; //第一个方块上侧与panel相距为50
            int i, j;
            for (j = 0; j < Y_CUBES_NUM; j++, x = 25, y += 39)
            {
                for (i = 0; i < X_CUBES_NUM; i++, x += 39)
                {
                    this.panel1.Controls.Add(map[i, j]);
                    map[i, j].Left = x;
                    map[i, j].Top = y;
                    Cube.Set_location(map[i, j], i, j);   //写入位置数据
                }
            }
        }


        //奖励时间
        public void Time_bouns()
        {
            double bonus = (double)marked_cubes.Count / thr_bonus_time;
            int bonus_time = (Int16)Math.Ceiling(bonus);
            New_Time = bonus_time;
            Time_Need_Update = true;
            //显示+1s
            Thread thread_show_time_add1s = new Thread(new ThreadStart(Time_show_add1s));
            thread_show_time_add1s.IsBackground = true;
            thread_show_time_add1s.Start();
        }

        //显示时间上+1s线程
        public void Time_show_add1s()
        {
            SetTimeAdd1sLabelVisibililtyEventHandler setTimeAdd1SLabelVisibililtyEvent = new SetTimeAdd1sLabelVisibililtyEventHandler(Set_time_add1s_label_visiblility);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 1, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 1, false);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 2, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 2, false);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 3, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setTimeAdd1SLabelVisibililtyEvent, 3, false);
        }

        //计分
        public void Score_count()
        {
            SetScoreLabelTextEventHandler setScoreLabelTextEvent = new SetScoreLabelTextEventHandler(Set_Score_Label_Text);
            int cube_amount = marked_cubes.Count;
            if (cube_amount == 3) score += 1;
            else if (cube_amount == 4) score += 2;
            else if (cube_amount == 5) score += 4;
            else if (cube_amount >= 6) score += (Int16)(Math.Ceiling((double)cube_amount * 1.5));
            this.Invoke(setScoreLabelTextEvent, score);
            //显示分数上+1s
            Thread thread_show_score_add1s = new Thread(new ThreadStart(Score_show_add1s));
            thread_show_score_add1s.IsBackground = true;
            thread_show_score_add1s.Start();
        }

        //显示分数上+1s线程
        public void Score_show_add1s()
        {
            SetScoreAdd1sLabelVisibililtyEventHandler setScoreAdd1SLabelVisibililtyEvent = new SetScoreAdd1sLabelVisibililtyEventHandler(Set_score_add1s_label_visiblility);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 1, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 1, false);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 2, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 2, false);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 3, true);
            System.Threading.Thread.Sleep(100);
            this.Invoke(setScoreAdd1SLabelVisibililtyEvent, 3, false);
        }



        /*-----------------------操作方块相关方法-------------------*/

        //标记方块
        public void Mark_cube(Cube cube)
        {
            marked_cubes.Add(cube);
        }

        //取消标记方块
        public void deMark_cube(Cube cube)
        {
            marked_cubes.Remove(cube);
        }

        //清空marked_cubes
        private void Clear_marked_cubes()
        {
            marked_cubes.Clear();
        }


        //设置可选择性
        public void Set_Around_Selectability(int I, int J, int Flag)  //I,J:当前块的横纵坐标（整数） Flag:为-1时，为取消选择，+1时，为选择
        {
            try
            {
                Clear_marked_cubes();
                int i, j;
                //选择计数
                if (Flag == 1) selected_cubes++;
                else if (Flag == -1) selected_cubes--;

                //根据selected_cubes判断接下来的操作
                if (selected_cubes == 2 && Flag == 1)           //当已经选择两方块时，其余方块不能选择
                {
                    for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            if (!map[i, j].Get_selection_state()) map[i, j].Select_Disabel();
                        }
                    }
                //               MessageBox.Show("当已经选择两方块时，其余方块不能选择");
                }
                else if (selected_cubes == 1 && Flag == 1)   //当选中方块时，且当前只有一个方块被选择时，只能选择其上下左右的方块  ;
                {
                    for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            map[i, j].Select_Disabel();
                        }
                    }
                    map[((I == X_CUBES_NUM - 1) ? I : I + 1), J].Select_Enabel();
                    map[((I == 0) ? I : I - 1), J].Select_Enabel();
                    map[I, ((J == Y_CUBES_NUM - 1) ? J : J + 1)].Select_Enabel();
                    map[I, ((J == 0) ? J : J - 1)].Select_Enabel();
                    map[I, J].Select_Enabel();



               //                MessageBox.Show("当选中方块时，且当前只有一个方块被选择时，只能选择其上下左右的方块");
                }
                else if (selected_cubes == 1 && Flag == -1)   //当取消选中方块时，且当前只有一个方块被选择时，只能选择已选方块的上下左右方块  ;
                {
                    List<Cube> pin_cubes = new List<Cube>();
                    for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            if (map[i, j].Get_selection_state())
                            {
                                pin_cubes.Add(map[((i == (X_CUBES_NUM - 1)) ? i : (i + 1)), j]);
                                pin_cubes.Add(map[((i == 0) ? i : i - 1), j]);
                                pin_cubes.Add(map[i, ((j == (Y_CUBES_NUM - 1)) ? j : (j + 1))]);
                                pin_cubes.Add(map[i, ((j == 0) ? j : j - 1)]);
                                pin_cubes.Add(map[i, j]);
                            }
                            else
                            {
                                map[i, j].Select_Disabel();
                            }

                            foreach (Cube cube in pin_cubes)
                            {
                                cube.Select_Enabel();
                            }

                            Clear_marked_cubes();

                        }
                    }
                //                    MessageBox.Show("当取消选中方块时，且当前只有一个方块被选择时，只能选择已选方块的上下左右方块");
                }
                else         //当没有方块选中时，所有方块都可选择
                {
                    for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            map[i, j].Select_Enabel();
                        }
                    }
                 //                     MessageBox.Show("当没有方块选中时，所有方块都可选择");
                }

            /*
            Clear_marked_cubes();
            MessageBox.Show("标记矩阵中方块数："+marked_cubes.Count().ToString()+"\r\n"+"Flag="+Flag+"\r\n"+"选中方块数："+selected_cubes);
            map[((I == X_CUBES_NUM - 1) ? I : I + 1), J].Mark();
            map[((I == 0) ? I : I - 1), J].Mark();
            map[I, ((J == Y_CUBES_NUM - 1) ? J : J + 1)].Mark();
            map[I, ((J == 0) ? J : J - 1)].Mark();
            MessageBox.Show("标记矩阵中方块数：" + marked_cubes.Count().ToString() + "\r\n" + "Flag=" + Flag+"\r\n" + "选中方块数：" + selected_cubes);
            foreach (Cube cube in marked_cubes)
            {
                MessageBox.Show("X,Y=" + (cube.Get_Location_x()+1).ToString() + "," + (cube.Get_Location_y()+1).ToString() + " Selectable?:"+cube.Get_selectability_state().ToString());
            }
            Clear_marked_cubes();

            MessageBox.Show("函数已经运行：" + set_selectability_count + "次");
            MessageBox.Show("X,Y=9,9" + " Selectable?:" + map[8,8].Get_selectability_state().ToString());
            */
            }
            catch (Exception e)
            {
            //异常处理
                MessageBox.Show(e.Message);
            }
        }
        /*----------------------------交换方块有关方法--------------------------*/
        //将方块放入Selected_List中
        public void Put_cube_into_SelectList(Cube cube)
        {
            Selected_cube_List.Add(cube);
        }

        //将方块从Selected_List中移出
        public void Remove_cube_from_SelectList(Cube cube)
        {
            Selected_cube_List.Remove(cube);
        }

        //交换两选中的方块
        public void Switch_cubes()
        {
            try
            {
                if (Selected_cube_List.Count == 2)
                {
                    Cube cube1, cube2;
                    cube1 = Selected_cube_List[0];
                    cube2 = Selected_cube_List[1];
                    int temp_type = 1;
                    temp_type = Cube.Get_type(cube1);
                    Cube.Set_type(cube1, Cube.Get_type(cube2));
                    Cube.Set_type(cube2, temp_type);
                    //！！！会出现未将应用对象赋值到实例错误
                    cube1.Refresh_Cube();
                    cube2.Refresh_Cube();
                    if(Scan_Killable_Cubes() == false)   //如果没有可以消除的方块
                    {
                        System.Threading.Thread.Sleep(200);  //延时0.2秒
                        deSwitch_cubes();   //将两方块再交换回去
                    }
                    else   //否则将两方块交换并消除可消除的方块
                    {
                        //消除可消除的方块
                        this.thread_scan_and_kill_cubes = new Thread(new ThreadStart(Scan_and_Kill_cubes));
                        this.thread_scan_and_kill_cubes.IsBackground = true;
                        this.thread_scan_and_kill_cubes.Start();
                        //清空选择有关的数据
                        Selected_cube_List.Clear();
                        selected_cubes = 0;
                        //交换后所有方块都能选择
                        int i, j;
                        for (j = 0; j < Y_CUBES_NUM; j++)
                        {
                            for (i = 0; i < X_CUBES_NUM; i++)
                            {
                                map[i, j].Select_Enabel();
                            }
                        }
                    }


                }
            }
            catch(Exception e)
            {
              //  MessageBox.Show(e.Message + "\r\n" + "selected_cubes = " + selected_cubes + "\r\nCubes in SelectedList = " + Selected_cube_List.Count);
            }

        }

        //取消两方块的交换
        public void deSwitch_cubes()
        {
            try
            {
                //将两方块交换回去
                Cube cube1, cube2;
                cube1 = Selected_cube_List[0];
                cube2 = Selected_cube_List[1];
                int temp_type = 1;
                temp_type = Cube.Get_type(cube1);
                Cube.Set_type(cube1, Cube.Get_type(cube2));
                Cube.Set_type(cube2, temp_type);
                cube1.Refresh_Cube();
                cube2.Refresh_Cube();
                //清空选择有关的数据
                Selected_cube_List.Clear();
                selected_cubes = 0;
                //交换后所有方块都能选择
                int i, j;
                for (j = 0; j < Y_CUBES_NUM; j++)
                {
                    for (i = 0; i < X_CUBES_NUM; i++)
                    {
                        map[i, j].Select_Enabel();
                    }
                }
            }
            catch(Exception e)
            {
                //do nothing
            }
        }

        //监听是否发生交换
        public void Switch_listening()
        {
            while(true)
            {
                if(selected_cubes == 2)
                {
                    Switch_cubes();
                }
            }
        }

        //方块消除后下落并生成新的方块
        public void Generate_new_cubes()
        {
            int i, j, k, empty_count;
            Random random = new Random(DateTime.Now.Second);
            empty_count = 0;
            List<int> verticle_entity_cube_origin = new List<int>(Y_CUBES_NUM);   //有图的方块的始发点
            List<int> verticle_entity_cube_type = new List<int>(Y_CUBES_NUM);
            //逐列扫描
            for(i=0;i<X_CUBES_NUM;i++,j=0,k=0,empty_count = 0)
            {
                for(j=Y_CUBES_NUM-1;j>=0;j--)   //从下往上找
                {
                    if(map[i,j].Get_this_type() == 0)
                    {
                        // verticle_empty_cube.Add(map[i, j]);
                        //Cube.Set_type(map[i, empty_count], 0);
                        //map[i, empty_count].Refresh_Cube();
                        empty_count++;
                        
                    }
                    else
                    {
                        verticle_entity_cube_type.Add(map[i, j].Get_this_type());
                        verticle_entity_cube_origin.Add(j);
                    }
                }
/*
                for(k=0;k<verticle_entity_cube_type.Count;k++)
                {
                    
                    int origin, destination;
                    origin = verticle_entity_cube_origin[k];
                    destination = Y_CUBES_NUM - 1 - k;
                    int n;
                    for(n=origin;n<destination;n++)
                    {
                        Cube.Set_type(map[i, n], verticle_entity_cube_type[k]);
                    }
                    System.Threading.Thread.Sleep(100);
                }
*/        

                for(k=0, j = Y_CUBES_NUM - 1; k<verticle_entity_cube_type.Count;k++,j--)
                {
                    Cube.Set_type(map[i, j], verticle_entity_cube_type[k]);
                }

                for(k=0;k<empty_count;k++)
                {
                    Cube.Set_type(map[i, k], random.Next(1, TOTAL_CUBE_TYPE));
                }

                verticle_entity_cube_type.Clear();

            }



            for(i=0;i<X_CUBES_NUM;i++)
            {
                for(j=Y_CUBES_NUM-1;j>=0;j--)
                {
                    map[i, j].Refresh_Cube();
                    //System.Threading.Thread.Sleep(200);
                    //MessageBox.Show(map[i,j].Get_Location_x().ToString() + " " + map[i,j].Get_Location_y().ToString());
                }
            }

        }



        /*----------------------------消除方块相关方法--------------------*/
        //消除方块的方法
        public Boolean Scan_Killable_Cubes()    //if is killable, return true
        {
            Boolean isClean = false;
            int[,] type_matrix = new int[X_CUBES_NUM, Y_CUBES_NUM];
            int i, j;

            try
            {
                //将类型信息录入type_matrix
                for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            type_matrix[i, j] = Cube.Get_type(map[i, j]);
                        }
                    }

                    //清除现有标记
                    Clear_marked_cubes();


                //逐行逐列扫描是否有三个以上相同类型的方块
                    int current_type, count_cubes;
                    int[] premark_i = new int[X_CUBES_NUM];
                    int[] premark_j = new int[Y_CUBES_NUM];
                    for (i = 0; i < X_CUBES_NUM; i++)
                    {
                        premark_i[i] = -1;
                    }
                    for (i = 0; i < Y_CUBES_NUM; i++)
                    {
                        premark_j[i] = -1;
                    }
                    //逐行扫描
                    current_type = 0;
                    count_cubes = 0;
                    for (j = 0; j < Y_CUBES_NUM; j++)
                    {
                        for (i = 0; i < X_CUBES_NUM; i++)
                        {
                            if (type_matrix[i, j] == current_type)
                            {
                                count_cubes++;
                                premark_i[count_cubes] = i;
                            }
                            else
                            {
                                if (count_cubes >= 2) Mark_horizontal_consecutive_cubes(premark_i, j);
                                count_cubes = 0;
                                current_type = type_matrix[i, j];
                                premark_i[count_cubes] = i;
                            }
                        }

                        if (count_cubes >= 2) Mark_horizontal_consecutive_cubes(premark_i, j);
                        count_cubes = 0;
                        current_type = 0;
                    }

                    //逐列扫描
                    current_type = 0;
                    count_cubes = 0;
                    for (i = 0; i < X_CUBES_NUM; i++)
                    {
                        for (j = 0; j < Y_CUBES_NUM; j++)
                        {
                            if (type_matrix[i, j] == current_type)
                            {
                                count_cubes++;
                                premark_j[count_cubes] = j;
                            }
                            else
                            {
                                if (count_cubes >= 2) Mark_verticle_consecutive_cubes(i, premark_j);
                                count_cubes = 0;
                                current_type = type_matrix[i, j];
                                premark_j[count_cubes] = j;
                            }
                        }
                        if (count_cubes >= 2) Mark_verticle_consecutive_cubes(i, premark_j);
                        count_cubes = 0;
                        current_type = 0;
                    }

                    if (marked_cubes.Count != 0) isClean = true; 
                    else isClean = false;

                    return isClean;

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return false;
            }
        }

        //横向标记可消除的块
        public void Mark_horizontal_consecutive_cubes(int[] premark_i, int j)
        {
            foreach (int x in premark_i)
            {
                if( x>=0 )  map[x, j].Mark();
            }
        }

        //纵向标记可消除的块
        public void Mark_verticle_consecutive_cubes(int i,int[] premark_j)
        {
            foreach (int x in premark_j)
            {
                if (x >= 0) map[i, x].Mark();
            }
        }

        //消除标记的方块
        public void kill_cubes()
        {
            //消除已标记的方块
            foreach (Cube cube in marked_cubes)
            {
                cube.Clear();
            }

            //奖励时间
            Time_bouns();

            //计算分数
            Score_count();

            //重绘界面
            ReDrawInterfaceEventHandler reDrawInterfaceEvent = new ReDrawInterfaceEventHandler(Draw_Cubes);
            this.Invoke(reDrawInterfaceEvent, map);

            //清除标记矩阵
            Clear_marked_cubes();

            //播放音效
            Thread thread_sound_play = new Thread(new ParameterizedThreadStart(Sound_play));
            thread_sound_play.Start("score");

            /*
            //生成新的图像
            Generate_new_cubes();
            */
        }

        //消除方块的线程
        public void Scan_and_Kill_cubes()
        {
            while (Scan_Killable_Cubes())
            {
                kill_cubes();
                Generate_new_cubes();
            }
        }


        /*--------------------------------声音视频有关方法--------------------------*/
        public void Sound_play(Object sound_type)   //type为hurt,score,bgm三种选项
        {
            //确定范围
            int sound_range = 1;
            switch(sound_type)
            {
                case "hurt": { sound_range = 9; break; }
                case "score": { sound_range = 10; break; }
                case "bgm": { sound_range = 1; break; }
            }
            //播放音效
            Random random = new Random(DateTime.Now.Second);
            String sound_num = random.Next(1, sound_range).ToString();
            SoundPlayer soundPlayer = new SoundPlayer(sound_path_head + sound_type.ToString() + sound_num + ".wav");
            soundPlayer.Play();
        }

        //播放视频线程
        public void Vedio_play()
        {
            this.Time_Stop = true;

            foreach(Cube cube in map)
            {
                cube.Select_Disabel();
            }

            Form_Vedio form_Vedio = new Form_Vedio(this.Vedio_Type);
            form_Vedio.closeFormEvent += new CloseFormEventHandler(Close_Form);
            form_Vedio.ShowDialog();

            foreach (Cube cube in map)
            {
                cube.Select_Enabel();
            }


        }

/*
        //监听是否播放视频
        public void Vedio_Listening()
        {
            int last_score;
            last_score = 0;
            Boolean play_vedio_flag = false;
            Boolean play_vedio_flag2 = false; 
            while(true)
            {
                if (score != last_score)
                {
                    if (score >= 50 && last_score < 50) { play_vedio_flag = true; this.Vedio_Type = 1; }
                    else if (score >= 80 && last_score < 80) { play_vedio_flag = true; this.Vedio_Type = 2; }
                    else if (score >= 100 && last_score < 100) { play_vedio_flag = true; this.Vedio_Type = 3; }
                    else { play_vedio_flag = false; play_vedio_flag2 = true; }
                    }
                else
                {
                    play_vedio_flag = false;
                    play_vedio_flag2 = true;
                }

                if(play_vedio_flag && play_vedio_flag2)
                {
                    play_vedio_flag = false;
                    play_vedio_flag2 = false;
                    Time_Stop = true;
                    Thread thread_play_vedio = new Thread(new ThreadStart(Vedio_play));
                    thread_play_vedio.SetApartmentState(ApartmentState.STA);
;                   thread_play_vedio.Start();
                }

            }
        }
*/


        /*----------------------------------------时间有关方法--------------------------*/

        //时间条走动
        public void Timebar_move()
        {
            if(this.progressBar_time.Value <= this.progressBar_time.Maximum)
            {
                this.progressBar_time.Value += this.progressBar_time.Step;
            }       
        }

        //时间条初始化
        public void Timebar_initial(int time)
        {
            this.progressBar_time.Maximum = INITIAL_TIME;
            this.progressBar_time.Step = 1;
            this.progressBar_time.Value = INITIAL_TIME - time;
            this.progressBar_time.ForeColor = Color.Aqua;
            this.progressBar_time.BackColor = Color.Red ;
        }

        //秒数显示
        public void TimeLabel_update(int time)
        {
            this.label_time.Text = time.ToString();
        }

        //判断是否有奖励并更新时间


        //计时线程
        public void time_count(Object time)
        {
            TimeBarMoveEventHandler timeBarMoveEvent = new TimeBarMoveEventHandler(Timebar_move);
            TimeLabelUpdateEventHandler timeLabelUpdateEvent = new TimeLabelUpdateEventHandler(TimeLabel_update);
            TimeBarInitialEventHandler timeBarInitialEvent = new TimeBarInitialEventHandler(Timebar_initial);
            SetRestartGameButtonVisibleEventHandler setRestartGameButtonVisibleEvent = new SetRestartGameButtonVisibleEventHandler(Set_RestartButton_Visible);

            int count;
            String str_time = time.ToString();
            count = Int16.Parse(str_time);

            this.Invoke(timeBarInitialEvent, time);

            try
            {
                while (count >= 0)
                {
                    if (Time_Need_Update == true)
                    {
                        count += New_Time;
                        count = (count > INITIAL_TIME ? INITIAL_TIME : count);
                        this.Invoke(timeBarInitialEvent, count);
                        Time_Need_Update = false;
                    }
                    if(Time_Stop == false) count--;
                    System.Threading.Thread.Sleep(1000);
                    this.Invoke(timeLabelUpdateEvent, count);
                    if (count == 0) break;
                    this.Invoke(timeBarMoveEvent);
;
                }
                //临时方案
                

                foreach (Cube cube in map)
                {
                    cube.Select_Disabel();
                }

                Sound_play("hurt");

                String notice = "";
                Boolean next_level = false;

                if (score >= Score_line_pass && score < Score_line_average) { this.Vedio_Type = 1; notice = "\r\n获得观看葛底斯堡演说的机会"; }
                else if (score >= Score_line_average && score < Score_line_outstanding) { this.Vedio_Type = 2; notice = "\r\n获得欣赏革命歌曲的机会"; }
                else if (score >= Score_line_outstanding) { this.Vedio_Type = 3; notice = "\r\n获得欣赏《毕业歌》的机会"; }
                else this.Vedio_Type = 0;

                MessageBox.Show("您一共续了" + score + "秒" + notice);

                if (this.Vedio_Type != 0)
                {
                    this.Game_achievement++;
                    next_level = true;
                    Thread thread_play_vedio = new Thread(new ThreadStart(Vedio_play));
                    thread_play_vedio.IsBackground = true;
                    thread_play_vedio.SetApartmentState(ApartmentState.STA);
                    thread_play_vedio.Start();
                }

                this.Invoke(setRestartGameButtonVisibleEvent,next_level);

                foreach (Cube cube in map)
                {
                    cube.Select_Disabel();
                }

                //this.Invoke(closeFormEvent);
                //待修改
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }


    }

}
