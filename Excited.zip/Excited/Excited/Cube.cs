﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Excited
{
    public partial class Cube : UserControl
    {
        /*-------------------------------委托----------------------------*/
        public delegate void RefreshPictureBoxEventHandler();
        public delegate void ResetPictureBoxBorderEventHandler();

        /*-------------------------------事件----------------------------*/
        public event Form_Game.SetSelectabilityEventHandler SetSelectabilityEvent;
        public event Form_Game.MarkCubeEventHandler MarkCubeEvent;
        public event Form_Game.deMarkCubeEventHandler deMarkCubeEvent;
        public event Form_Game.PutIntoSelectedListEventHandler PutIntoSelectedListEvent;
        public event Form_Game.RemoveFromSelectedListEventHandler RemoveFromSelectedListEvent;

        /*-----------------------------控件属性信息----------------------*/
        private int type; //类型
        private int location_x; //横向位置
        private int location_y; //纵向位置
        private Boolean isSelected; //是否被选中
        private Boolean isSelectabel; //是否能被选中
        private static String pic_path_head = System.AppDomain.CurrentDomain.BaseDirectory + @"components\icon\";  //+ this.type.ToString() + ".jpg";
        private static String sound_path_head = System.AppDomain.CurrentDomain.BaseDirectory + @"components\sounds\";  //+ "Filename"

        /*-------------------------构造函数们-----------------------------*/
        public Cube()
        {
            InitializeComponent();

            //！初始化信息
        }

        
        public Cube(int type)
        {
            InitializeComponent();
            //初始化参数
            this.type = type;
            this.isSelectabel = true;
            this.isSelected = false;
            //附加图片
            Set_pic();

        }

        /*-------------------------------控件函数----------------------*/


        //点击图片时，改变该块的状态
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (this.isSelectabel == true)
            {
                if(this.isSelected == true )
                {
                    this.isSelected = false;
                    this.pictureBox1.BorderStyle = BorderStyle.None;
                    this.BackColor = Color.Transparent;  //设置底色为透明
                    SetSelectabilityEvent(this.location_x, this.location_y, -1); //
                    this.Remove_From_Selected_List();
                }
                else
                {
                    this.isSelected = true;
                    this.pictureBox1.BorderStyle = BorderStyle.Fixed3D;
                    this.BackColor = Color.Aqua; //设置底色为青色
                    //播放音效
                    String sound_path = sound_path_head + "flap.wav";
                    SoundPlayer player = new SoundPlayer(sound_path);
                    player.Play();
                    //使周边外禁止选择
                    //if(SetSelectabilityEvent != null)
                    //{
                        SetSelectabilityEvent(this.location_x,this.location_y,1);
                    //}
                    this.Put_into_Selected_List();
                }

            } 

        }

 

        /*--------------------------控制方法------------------------*/

        //获取当前块类型
        public static int Get_type(Cube cube)
        {
            return cube.type;
        }

        public int Get_this_type()
        {
            return this.type;
        }

        //获取当前块是否被选中
        public Boolean Get_selection_state()
        {
            return this.isSelected;
        }

        //获取当前块能否被选中
        public Boolean Get_selectability_state()
        {
            return this.isSelectabel;
        }

        //获取当前块横坐标
        public int Get_Location_x()
        {
            return this.location_x;
        }

        //获取当前块纵坐标
        public int Get_Location_y()
        {
            return this.location_y;
        }


        //设置当前块的类型
        public static void Set_type(Cube cube,int type)
        {
            cube.type = type;
        }

        //设置当前块位置（map中）
        public static void Set_location(Cube cube,int i, int j)
        {
            cube.location_x = i;
            cube.location_y = j;
        }

        //在map中标记当前块
        public void Mark()
        {
            MarkCubeEvent(this);
        }

        //在map中取消标记当前块
        public void deMark()
        {
            deMarkCubeEvent(this);
        }

        //为当前块加载图片
        public void Set_pic()
        {
            if(this.type != 0)
            {
                String pic_path = pic_path_head + this.type.ToString() + ".jpg";
                Image image = Image.FromFile(pic_path);
                this.pictureBox1.Image = image;
                this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                this.pictureBox1.Image = null;
            }

        }


        //设置不能对该块进行选中
        public void Select_Disabel()
        {
            this.isSelectabel = false;
        }

        //设置能对该块进行选中
        public void Select_Enabel()
        {
            this.isSelectabel = true;
        }

        //加入到已选择列表中
        public void Put_into_Selected_List()
        {
            PutIntoSelectedListEvent(this);
        }

        //从已选择列表中移出
        public void Remove_From_Selected_List()
        {
            RemoveFromSelectedListEvent(this);
        }

        //消除该块
        public void Clear()
        {
            RefreshPictureBoxEventHandler refreshPictureBoxEvent = new RefreshPictureBoxEventHandler(Clear_Picture);
            this.type = 0;
            this.Invoke(refreshPictureBoxEvent);
        }

        //清除图像
        public void Clear_Picture()
        {
            this.pictureBox1.Image = null;
            this.pictureBox1.Refresh();
        }

        //刷新方块状态
        public void Refresh_Cube()
        {
            //初始化参数
            this.isSelectabel = true;
            this.isSelected = false;
            //附加图片
            Set_pic();
            //设置状态
            ResetPictureBoxBorderEventHandler resetPictureBoxBorderEvent = new ResetPictureBoxBorderEventHandler(Reset_PictureBox_Border);
            this.Invoke(resetPictureBoxBorderEvent);
            //SetSelectabilityEvent(this.location_x, this.location_y, -1); //
            //this.Remove_From_Selected_List();
        }

        //重置图片边框
        public void Reset_PictureBox_Border()
        {
            this.pictureBox1.BorderStyle = BorderStyle.None;
            this.BackColor = Color.Transparent;  //设置底色为透明
        }



    }
}
