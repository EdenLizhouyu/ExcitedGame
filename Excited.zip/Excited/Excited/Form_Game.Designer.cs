﻿namespace Excited
{
    partial class Form_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_restart = new System.Windows.Forms.Button();
            this.button_start = new System.Windows.Forms.Button();
            this.label_time_label = new System.Windows.Forms.Label();
            this.progressBar_time = new System.Windows.Forms.ProgressBar();
            this.label_time = new System.Windows.Forms.Label();
            this.label_score_label = new System.Windows.Forms.Label();
            this.label_score = new System.Windows.Forms.Label();
            this.label_add1s_1 = new System.Windows.Forms.Label();
            this.label_add1s_2 = new System.Windows.Forms.Label();
            this.label_add1s_3 = new System.Windows.Forms.Label();
            this.label_time_add1s_1 = new System.Windows.Forms.Label();
            this.label_time_add1s_2 = new System.Windows.Forms.Label();
            this.label_time_add1s_3 = new System.Windows.Forms.Label();
            this.label_level = new System.Windows.Forms.Label();
            this.label_goal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_restart);
            this.panel1.Controls.Add(this.button_start);
            this.panel1.Location = new System.Drawing.Point(16, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 700);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button_restart
            // 
            this.button_restart.Font = new System.Drawing.Font("隶书", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_restart.Location = new System.Drawing.Point(128, 334);
            this.button_restart.Name = "button_restart";
            this.button_restart.Size = new System.Drawing.Size(257, 33);
            this.button_restart.TabIndex = 5;
            this.button_restart.Text = "再续一局";
            this.button_restart.UseVisualStyleBackColor = true;
            this.button_restart.Visible = false;
            this.button_restart.Click += new System.EventHandler(this.button_restart_Click);
            // 
            // button_start
            // 
            this.button_start.Font = new System.Drawing.Font("隶书", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_start.Location = new System.Drawing.Point(184, 334);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(145, 33);
            this.button_start.TabIndex = 4;
            this.button_start.Text = "为长者续命";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // label_time_label
            // 
            this.label_time_label.AutoSize = true;
            this.label_time_label.Font = new System.Drawing.Font("宋体", 12F);
            this.label_time_label.Location = new System.Drawing.Point(13, 27);
            this.label_time_label.Name = "label_time_label";
            this.label_time_label.Size = new System.Drawing.Size(69, 20);
            this.label_time_label.TabIndex = 1;
            this.label_time_label.Text = "时间：";
            // 
            // progressBar_time
            // 
            this.progressBar_time.Location = new System.Drawing.Point(88, 24);
            this.progressBar_time.Name = "progressBar_time";
            this.progressBar_time.Size = new System.Drawing.Size(386, 23);
            this.progressBar_time.TabIndex = 2;
            // 
            // label_time
            // 
            this.label_time.AutoSize = true;
            this.label_time.Location = new System.Drawing.Point(492, 31);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(0, 15);
            this.label_time.TabIndex = 3;
            // 
            // label_score_label
            // 
            this.label_score_label.AutoSize = true;
            this.label_score_label.Location = new System.Drawing.Point(12, 71);
            this.label_score_label.Name = "label_score_label";
            this.label_score_label.Size = new System.Drawing.Size(67, 15);
            this.label_score_label.TabIndex = 4;
            this.label_score_label.Text = "已众筹：";
            // 
            // label_score
            // 
            this.label_score.AutoSize = true;
            this.label_score.Location = new System.Drawing.Point(85, 71);
            this.label_score.Name = "label_score";
            this.label_score.Size = new System.Drawing.Size(0, 15);
            this.label_score.TabIndex = 5;
            // 
            // label_add1s_1
            // 
            this.label_add1s_1.AutoSize = true;
            this.label_add1s_1.BackColor = System.Drawing.Color.Transparent;
            this.label_add1s_1.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_add1s_1.Location = new System.Drawing.Point(101, 61);
            this.label_add1s_1.Name = "label_add1s_1";
            this.label_add1s_1.Size = new System.Drawing.Size(31, 15);
            this.label_add1s_1.TabIndex = 6;
            this.label_add1s_1.Text = "+1s";
            this.label_add1s_1.Visible = false;
            // 
            // label_add1s_2
            // 
            this.label_add1s_2.AutoSize = true;
            this.label_add1s_2.BackColor = System.Drawing.Color.Transparent;
            this.label_add1s_2.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_add1s_2.Location = new System.Drawing.Point(123, 50);
            this.label_add1s_2.Name = "label_add1s_2";
            this.label_add1s_2.Size = new System.Drawing.Size(31, 15);
            this.label_add1s_2.TabIndex = 7;
            this.label_add1s_2.Text = "+1s";
            this.label_add1s_2.Visible = false;
            // 
            // label_add1s_3
            // 
            this.label_add1s_3.AutoSize = true;
            this.label_add1s_3.BackColor = System.Drawing.Color.Transparent;
            this.label_add1s_3.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_add1s_3.Location = new System.Drawing.Point(112, 32);
            this.label_add1s_3.Name = "label_add1s_3";
            this.label_add1s_3.Size = new System.Drawing.Size(31, 15);
            this.label_add1s_3.TabIndex = 8;
            this.label_add1s_3.Text = "+1s";
            this.label_add1s_3.Visible = false;
            // 
            // label_time_add1s_1
            // 
            this.label_time_add1s_1.AutoSize = true;
            this.label_time_add1s_1.BackColor = System.Drawing.Color.Transparent;
            this.label_time_add1s_1.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_time_add1s_1.Location = new System.Drawing.Point(504, 24);
            this.label_time_add1s_1.Name = "label_time_add1s_1";
            this.label_time_add1s_1.Size = new System.Drawing.Size(31, 15);
            this.label_time_add1s_1.TabIndex = 9;
            this.label_time_add1s_1.Text = "+1s";
            this.label_time_add1s_1.Visible = false;
            this.label_time_add1s_1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label_time_add1s_2
            // 
            this.label_time_add1s_2.AutoSize = true;
            this.label_time_add1s_2.BackColor = System.Drawing.Color.Transparent;
            this.label_time_add1s_2.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_time_add1s_2.Location = new System.Drawing.Point(519, 9);
            this.label_time_add1s_2.Name = "label_time_add1s_2";
            this.label_time_add1s_2.Size = new System.Drawing.Size(31, 15);
            this.label_time_add1s_2.TabIndex = 10;
            this.label_time_add1s_2.Text = "+1s";
            this.label_time_add1s_2.Visible = false;
            // 
            // label_time_add1s_3
            // 
            this.label_time_add1s_3.AutoSize = true;
            this.label_time_add1s_3.BackColor = System.Drawing.Color.Transparent;
            this.label_time_add1s_3.ForeColor = System.Drawing.Color.ForestGreen;
            this.label_time_add1s_3.Location = new System.Drawing.Point(510, -6);
            this.label_time_add1s_3.Name = "label_time_add1s_3";
            this.label_time_add1s_3.Size = new System.Drawing.Size(31, 15);
            this.label_time_add1s_3.TabIndex = 11;
            this.label_time_add1s_3.Text = "+1s";
            this.label_time_add1s_3.Visible = false;
            // 
            // label_level
            // 
            this.label_level.AutoSize = true;
            this.label_level.Location = new System.Drawing.Point(309, 71);
            this.label_level.Name = "label_level";
            this.label_level.Size = new System.Drawing.Size(47, 15);
            this.label_level.TabIndex = 12;
            this.label_level.Text = "level";
            // 
            // label_goal
            // 
            this.label_goal.AutoSize = true;
            this.label_goal.Location = new System.Drawing.Point(144, 69);
            this.label_goal.Name = "label_goal";
            this.label_goal.Size = new System.Drawing.Size(87, 15);
            this.label_goal.TabIndex = 13;
            this.label_goal.Text = "label_goal";
            // 
            // Form_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(584, 853);
            this.Controls.Add(this.label_goal);
            this.Controls.Add(this.label_level);
            this.Controls.Add(this.label_time_add1s_3);
            this.Controls.Add(this.label_time_add1s_2);
            this.Controls.Add(this.label_time_add1s_1);
            this.Controls.Add(this.label_add1s_3);
            this.Controls.Add(this.label_add1s_2);
            this.Controls.Add(this.label_add1s_1);
            this.Controls.Add(this.label_score);
            this.Controls.Add(this.label_score_label);
            this.Controls.Add(this.label_time);
            this.Controls.Add(this.progressBar_time);
            this.Controls.Add(this.label_time_label);
            this.Controls.Add(this.panel1);
            this.Name = "Form_Game";
            this.Text = "长者消消乐";
            this.Load += new System.EventHandler(this.Form_Game_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_time_label;
        private System.Windows.Forms.ProgressBar progressBar_time;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Label label_score_label;
        private System.Windows.Forms.Label label_score;
        private System.Windows.Forms.Label label_add1s_1;
        private System.Windows.Forms.Label label_add1s_2;
        private System.Windows.Forms.Label label_add1s_3;
        private System.Windows.Forms.Label label_time_add1s_1;
        private System.Windows.Forms.Label label_time_add1s_2;
        private System.Windows.Forms.Label label_time_add1s_3;
        private System.Windows.Forms.Button button_restart;
        private System.Windows.Forms.Label label_level;
        private System.Windows.Forms.Label label_goal;
    }
}