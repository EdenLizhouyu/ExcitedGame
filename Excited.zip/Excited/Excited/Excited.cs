﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Excited
{
    public partial class Excited : Form
    {
        public Excited()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_start_Click(object sender, EventArgs e)
        {
            Thread thread_Game_start = new Thread(new ThreadStart(start_game));
            thread_Game_start.Start();
            this.Close();
        }

        //开始游戏线程执行的函数
        public void start_game()
        {
            Form_Game form_game = new Form_Game(0,0);
            form_game.ShowDialog();
        }

        private void button_rules_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.fmprc.gov.cn/web/ziliao_674904/tytj_674911/tyfg_674913/t70829.shtml");
        }
    }
}
