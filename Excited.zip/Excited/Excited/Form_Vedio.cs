﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Excited
{
    public partial class Form_Vedio : Form
    {
        private static String vedio_path_head = System.AppDomain.CurrentDomain.BaseDirectory + @"components\vedios\";  //+ "Filename"   视频目录
        public event Form_Game.CloseFormEventHandler closeFormEvent;

        public Form_Vedio()
        {
            InitializeComponent();
        }

        public Form_Vedio(int Vedio_type)
        {
            InitializeComponent();
            this.WindowsMediaPlayer.URL = vedio_path_head + Vedio_type + ".mp4";
            this.WindowsMediaPlayer.Ctlcontrols.play();
            //closeFormEvent();
        }

        private void WindowsMediaPlayer_Enter(object sender, EventArgs e)
        {

        }
    }
}
